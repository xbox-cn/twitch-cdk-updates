-- Temporary per-account liveness outcome marker. This does not change the
-- account lifecycle status; it only records the last check result so an
-- operator can inspect accounts that failed for non-401 reasons.
ALTER TABLE accounts
    ADD COLUMN IF NOT EXISTS liveness_last_outcome VARCHAR(16),
    ADD COLUMN IF NOT EXISTS liveness_last_http_status INTEGER;

CREATE INDEX IF NOT EXISTS idx_accounts_liveness_errors
    ON accounts (liveness_checked_at DESC)
    WHERE liveness_last_outcome = 'error';
