-- Short-lived mailbox registry. Tokens stay server-side and are never sent to
-- the browser; the admin UI addresses mailboxes by local numeric id instead.
CREATE TABLE IF NOT EXISTS mailboxes (
    id         BIGSERIAL PRIMARY KEY,
    email      VARCHAR(320) NOT NULL,
    token      TEXT NOT NULL UNIQUE,
    domain     VARCHAR(255) NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_mailboxes_expires_at ON mailboxes (expires_at);
