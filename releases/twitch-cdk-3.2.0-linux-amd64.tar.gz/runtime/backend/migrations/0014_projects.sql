-- 0014_projects.sql
-- Projects become first-class records. Workers may only claim accounts for
-- registered, enabled project codes; each project owns its drop duration and
-- per-project concurrency limit.

BEGIN;

CREATE TABLE IF NOT EXISTS projects (
    id                      BIGSERIAL PRIMARY KEY,
    code                    VARCHAR(128) NOT NULL,
    name                    VARCHAR(256) NOT NULL,
    description             TEXT NOT NULL DEFAULT '',
    drop_duration_seconds   INT NOT NULL DEFAULT 600,
    worker_concurrency      INT NOT NULL DEFAULT 0,
    enabled                 BOOLEAN NOT NULL DEFAULT TRUE,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (code)
);

CREATE INDEX IF NOT EXISTS idx_projects_enabled
    ON projects (enabled, created_at DESC);

-- Preserve existing project strings from the previous string-only model.
INSERT INTO projects (code, name, description)
SELECT DISTINCT project, project, 'Migrated from existing project claims'
FROM account_projects
WHERE project <> ''
ON CONFLICT (code) DO NOTHING;

INSERT INTO projects (code, name, description)
SELECT DISTINCT project, project, 'Migrated from existing CDK rows'
FROM cdks
WHERE project <> ''
ON CONFLICT (code) DO NOTHING;

COMMIT;
