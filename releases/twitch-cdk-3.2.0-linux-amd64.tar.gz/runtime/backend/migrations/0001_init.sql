-- 0001_init.sql - initial schema for Twitch CDK Management v2

CREATE TABLE IF NOT EXISTS users (
    id            BIGSERIAL PRIMARY KEY,
    username      VARCHAR(128) UNIQUE NOT NULL,
    password_hash VARCHAR(256) NOT NULL,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS accounts (
    id              BIGSERIAL PRIMARY KEY,
    username        VARCHAR(128) NOT NULL DEFAULT '',
    password        VARCHAR(256) NOT NULL DEFAULT '',
    email           VARCHAR(256) NOT NULL DEFAULT '',
    auth_token      TEXT,
    cookies         TEXT,
    status          VARCHAR(32)  NOT NULL DEFAULT 'idle',
    register_time   TIMESTAMPTZ,
    last_claim_time TIMESTAMPTZ,
    current_cdk     VARCHAR(512),
    worker_id       VARCHAR(128),
    last_heartbeat  TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_accounts_status      ON accounts (status);
CREATE INDEX IF NOT EXISTS idx_accounts_created_at  ON accounts (created_at);
CREATE INDEX IF NOT EXISTS idx_accounts_worker_id   ON accounts (worker_id);

CREATE TABLE IF NOT EXISTS cdks (
    id            BIGSERIAL PRIMARY KEY,
    cdk_code      VARCHAR(512) NOT NULL DEFAULT '',
    game_name     VARCHAR(256) NOT NULL DEFAULT '',
    status        VARCHAR(32)  NOT NULL DEFAULT 'unused',
    claimed_by    BIGINT REFERENCES accounts(id) ON DELETE SET NULL,
    claimed_time  TIMESTAMPTZ,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_cdks_code       ON cdks (cdk_code);
CREATE INDEX IF NOT EXISTS idx_cdks_status     ON cdks (status);
CREATE INDEX IF NOT EXISTS idx_cdks_created_at ON cdks (created_at);

CREATE TABLE IF NOT EXISTS workers (
    id             BIGSERIAL PRIMARY KEY,
    worker_name    VARCHAR(128) NOT NULL DEFAULT '',
    worker_type    VARCHAR(32)  NOT NULL DEFAULT 'cdk',
    status         VARCHAR(32)  NOT NULL DEFAULT 'online',
    last_heartbeat TIMESTAMPTZ,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_workers_name ON workers (worker_name);
