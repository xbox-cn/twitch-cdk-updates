-- 0005_cdks_unique.sql
-- cdk_code 没有 UNIQUE 约束会让 ON CONFLICT DO NOTHING 失效,
-- 并发 import / claim 时可能产生重复 cdk_code。
-- 清理已有重复 + 加约束。

-- 1. 先清理已存在的重复 (保留 id 最小的一条; 含 exported 偏好)
DELETE FROM cdks
WHERE id IN (
    SELECT id FROM (
        SELECT id,
               ROW_NUMBER() OVER (
                   PARTITION BY cdk_code
                   ORDER BY (exported = true) DESC, id ASC
               ) AS rn
        FROM cdks
    ) t WHERE rn > 1
);

-- 2. 加 UNIQUE 约束
ALTER TABLE cdks ADD CONSTRAINT cdks_cdk_code_key UNIQUE (cdk_code);

-- 3. 旧的非-unique index 可以保留 (UNIQUE 会自动建索引),
--    删掉以减少冗余。
DROP INDEX IF EXISTS idx_cdks_code;
