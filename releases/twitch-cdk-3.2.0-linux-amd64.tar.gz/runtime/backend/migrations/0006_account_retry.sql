-- 0006_account_retry.sql
-- 账号首次失败后间隔 10 分钟重试一次，再失败则直接删除。
-- fail_count: 累计失败次数 (0=从未失败)
-- retry_after: 可被 get_idle 再次取走的时间 (NULL=立即可用)

BEGIN;

ALTER TABLE accounts
    ADD COLUMN IF NOT EXISTS fail_count  INT         NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS retry_after TIMESTAMPTZ;

CREATE INDEX IF NOT EXISTS idx_accounts_retry_after ON accounts (retry_after)
    WHERE retry_after IS NOT NULL;

COMMIT;
