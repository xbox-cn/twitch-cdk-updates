-- Drop the FK constraint permanently.
-- The purge logic now manually NULLs cdks.claimed_by before deleting accounts,
-- avoiding the slow ON DELETE SET NULL cascade.
ALTER TABLE cdks DROP CONSTRAINT IF EXISTS cdks_claimed_by_fkey;
