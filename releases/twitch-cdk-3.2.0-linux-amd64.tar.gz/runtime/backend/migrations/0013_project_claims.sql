-- 0013_project_claims.sql
-- Accounts become reusable across projects. A project claim records the
-- per-project lease/result; the account row only tracks availability.
--
-- Deletion policy:
--   * explicit DELETE / POST remove
--   * worker reports status=invalid with http_status=401
-- No failure-count, timeout or retention based account deletion.

BEGIN;

ALTER TABLE accounts
    ADD COLUMN IF NOT EXISTS current_project     VARCHAR(128),
    ADD COLUMN IF NOT EXISTS last_project        VARCHAR(128),
    ADD COLUMN IF NOT EXISTS last_project_status VARCHAR(32);

ALTER TABLE cdks
    ADD COLUMN IF NOT EXISTS project VARCHAR(128) NOT NULL DEFAULT '';

CREATE TABLE IF NOT EXISTS account_projects (
    id             BIGSERIAL PRIMARY KEY,
    account_id     BIGINT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
    project        VARCHAR(128) NOT NULL,
    status         VARCHAR(32) NOT NULL DEFAULT 'claiming',
    cdk_code       VARCHAR(512),
    worker_id      VARCHAR(128),
    claim_token    UUID,
    claim_deadline TIMESTAMPTZ,
    retry_after    TIMESTAMPTZ,
    fail_count     INT NOT NULL DEFAULT 0,
    claimed_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    finished_at    TIMESTAMPTZ,
    updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (account_id, project)
);

CREATE INDEX IF NOT EXISTS idx_account_projects_project_status
    ON account_projects (project, status);
CREATE INDEX IF NOT EXISTS idx_account_projects_account
    ON account_projects (account_id);
CREATE INDEX IF NOT EXISTS idx_account_projects_deadline
    ON account_projects (claim_deadline)
    WHERE status = 'claiming';

CREATE INDEX IF NOT EXISTS idx_cdks_project
    ON cdks (project)
    WHERE project <> '';
CREATE INDEX IF NOT EXISTS idx_cdks_project_exported
    ON cdks (project, exported)
    WHERE project <> '';

-- Legacy rows have no project name. Preserve their current lease/result as a
-- synthetic `legacy` project so in-flight workers can still report back.
INSERT INTO account_projects (
    account_id, project, status, cdk_code, worker_id, claim_token,
    claim_deadline, retry_after, fail_count, claimed_at, finished_at, updated_at
)
SELECT
    id,
    'legacy',
    status,
    current_cdk,
    CASE WHEN status = 'claiming' THEN worker_id ELSE NULL END,
    CASE WHEN status = 'claiming' THEN claim_token ELSE NULL END,
    CASE WHEN status = 'claiming' THEN COALESCE(claim_deadline, NOW()) ELSE NULL END,
    retry_after,
    fail_count,
    COALESCE(used_at, last_claim_time, created_at),
    CASE WHEN status = 'claiming' THEN NULL ELSE COALESCE(last_claim_time, used_at, created_at) END,
    NOW()
FROM accounts
WHERE status IN ('claiming', 'success', 'failed', 'nostock')
ON CONFLICT (account_id, project) DO NOTHING;

UPDATE accounts
SET current_project = CASE WHEN status = 'claiming' THEN 'legacy' ELSE NULL END,
    last_project = CASE
        WHEN status IN ('claiming', 'success', 'failed', 'nostock') THEN 'legacy'
        ELSE NULL
    END,
    last_project_status = CASE
        WHEN status = 'claiming' THEN 'claiming'
        WHEN status = 'success' THEN 'success'
        WHEN status = 'failed' THEN 'failed'
        WHEN status = 'nostock' THEN 'nostock'
        ELSE NULL
    END,
    status = CASE WHEN status = 'claiming' THEN 'claiming' ELSE 'available' END,
    is_nostock = FALSE,
    fail_count = 0,
    retry_after = NULL,
    worker_id = CASE WHEN status = 'claiming' THEN worker_id ELSE NULL END,
    claim_token = CASE WHEN status = 'claiming' THEN claim_token ELSE NULL END,
    claim_deadline = CASE WHEN status = 'claiming' THEN claim_deadline ELSE NULL END;

UPDATE cdks
SET project = 'legacy'
WHERE claimed_by IS NOT NULL AND project = '';

-- Retired: accounts are no longer deleted by retention.
DELETE FROM settings WHERE key = 'account_retention_hours';

COMMIT;
