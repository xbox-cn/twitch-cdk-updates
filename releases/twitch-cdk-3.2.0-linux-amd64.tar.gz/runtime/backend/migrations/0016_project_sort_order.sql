-- 0016_project_sort_order.sql
-- Project order is global, not a per-browser dashboard preference.

BEGIN;

ALTER TABLE projects
    ADD COLUMN IF NOT EXISTS sort_order INT NOT NULL DEFAULT 0;

UPDATE projects
SET sort_order = id
WHERE sort_order = 0;

CREATE INDEX IF NOT EXISTS idx_projects_sort_order
    ON projects (sort_order ASC, created_at ASC, id ASC);

COMMIT;
