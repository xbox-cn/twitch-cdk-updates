-- 0003_settings.sql - runtime-configurable settings (key/value)
-- Modified through /api/settings; loaded at startup and overridden on save.

CREATE TABLE IF NOT EXISTS settings (
    key         VARCHAR(128) PRIMARY KEY,
    value       TEXT NOT NULL,
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
