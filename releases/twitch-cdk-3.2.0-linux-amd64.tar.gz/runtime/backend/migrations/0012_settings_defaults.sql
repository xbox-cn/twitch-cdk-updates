-- 0012_settings_defaults.sql
-- Seed additive runtime settings. Existing operator values are never touched.

INSERT INTO settings (key, value) VALUES
    ('auth_version', '0'),
    ('worker_offline_seconds', '300'),
    ('trust_proxy', 'true'),
    ('strict_claim_ownership', 'false')
ON CONFLICT (key) DO NOTHING;
