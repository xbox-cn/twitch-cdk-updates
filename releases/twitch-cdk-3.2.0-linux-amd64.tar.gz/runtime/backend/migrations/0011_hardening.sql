-- 0011_hardening.sql
-- Additive hardening for existing deployments. The legacy 0001-0010 files are
-- kept byte-for-byte so SQLx migration checksums remain valid.

BEGIN;

-- ---------------------------------------------------------------------------
-- Claim lease token: lets a worker prove it still owns the account it took.
-- Optional by default (STRICT_CLAIM_OWNERSHIP=false) for old clients.
-- ---------------------------------------------------------------------------
ALTER TABLE accounts ADD COLUMN IF NOT EXISTS claim_token UUID;

-- Lifecycle defaults now match the v2/v3 state machine.
ALTER TABLE accounts ALTER COLUMN status SET DEFAULT 'unused';
ALTER TABLE cdks ALTER COLUMN status SET DEFAULT 'claimed';

-- ---------------------------------------------------------------------------
-- One account row per username. Reassign CDK references to the kept row
-- before deleting duplicates, so historical CDK ownership is preserved.
-- ---------------------------------------------------------------------------
CREATE TEMP TABLE duplicate_accounts ON COMMIT DROP AS
SELECT id, keep_id
FROM (
    SELECT id,
           first_value(id) OVER (
               PARTITION BY username
               ORDER BY id DESC
           ) AS keep_id
    FROM accounts
    WHERE username <> ''
) ranked
WHERE id <> keep_id;

UPDATE cdks AS cdk
SET claimed_by = duplicate.keep_id
FROM duplicate_accounts AS duplicate
WHERE cdk.claimed_by = duplicate.id;

DELETE FROM accounts AS account
USING duplicate_accounts AS duplicate
WHERE account.id = duplicate.id;

DROP INDEX IF EXISTS idx_accounts_username;
CREATE UNIQUE INDEX IF NOT EXISTS accounts_username_unique
    ON accounts (username)
    WHERE username <> '';

-- ---------------------------------------------------------------------------
-- Hot paths.
-- ---------------------------------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_accounts_claimable
    ON accounts (status, created_at, id)
    WHERE status IN ('unused', 'nostock');

CREATE INDEX IF NOT EXISTS idx_cdks_unexported_created
    ON cdks (created_at, id)
    WHERE exported = FALSE;

CREATE INDEX IF NOT EXISTS idx_cdks_claimed_by
    ON cdks (claimed_by)
    WHERE claimed_by IS NOT NULL;

-- ---------------------------------------------------------------------------
-- Trigram indexes make the leading-wildcard search usable at scale. If the
-- extension cannot be installed (managed DB without privileges), the
-- migration still succeeds and search falls back to a scan.
-- ---------------------------------------------------------------------------
DO $$
BEGIN
    BEGIN
        CREATE EXTENSION IF NOT EXISTS pg_trgm;
    EXCEPTION WHEN OTHERS THEN
        RAISE NOTICE 'pg_trgm unavailable: %', SQLERRM;
    END;

    IF EXISTS (SELECT 1 FROM pg_extension WHERE extname = 'pg_trgm') THEN
        EXECUTE 'CREATE INDEX IF NOT EXISTS idx_accounts_username_trgm ON accounts USING gin (username gin_trgm_ops)';
        EXECUTE 'CREATE INDEX IF NOT EXISTS idx_accounts_email_trgm ON accounts USING gin (email gin_trgm_ops)';
        EXECUTE 'CREATE INDEX IF NOT EXISTS idx_accounts_current_cdk_trgm ON accounts USING gin (current_cdk gin_trgm_ops)';
        EXECUTE 'CREATE INDEX IF NOT EXISTS idx_cdks_code_trgm ON cdks USING gin (cdk_code gin_trgm_ops)';
        EXECUTE 'CREATE INDEX IF NOT EXISTS idx_cdks_game_trgm ON cdks USING gin (game_name gin_trgm_ops)';
    END IF;
END $$;

COMMIT;
