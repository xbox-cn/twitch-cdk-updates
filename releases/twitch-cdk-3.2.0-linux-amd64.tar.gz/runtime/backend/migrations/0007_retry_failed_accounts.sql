-- Give legacy failed accounts another chance: reset to unused so get_idle picks them up.
UPDATE accounts
SET status       = 'unused',
    fail_count   = 0,
    retry_after  = NULL,
    used_at      = NULL,
    current_cdk  = NULL,
    worker_id    = NULL
WHERE status = 'failed';
