-- 0017_remove_strict_claim_setting.sql
-- Claim ownership is mandatory for every worker write-back, so the toggle is
-- no longer read. Remove the stale runtime setting row.
DELETE FROM settings WHERE key = 'strict_claim_ownership';
