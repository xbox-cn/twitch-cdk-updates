-- 0015_project_game_name.sql
-- The game is a project property, not free-form CDK metadata. Existing projects
-- inherit their display name until an operator edits the game name.

BEGIN;

ALTER TABLE projects
    ADD COLUMN IF NOT EXISTS game_name VARCHAR(256) NOT NULL DEFAULT '';

UPDATE projects
SET game_name = LEFT(name, 256)
WHERE game_name = '';

COMMIT;
