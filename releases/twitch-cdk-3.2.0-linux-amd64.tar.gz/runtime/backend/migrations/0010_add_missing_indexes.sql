-- Add missing indexes for performance.
CREATE INDEX IF NOT EXISTS idx_accounts_username ON accounts (username);
CREATE INDEX IF NOT EXISTS idx_accounts_claim_deadline ON accounts (claim_deadline) WHERE claim_deadline IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_workers_last_heartbeat ON workers (last_heartbeat) WHERE last_heartbeat IS NOT NULL;
