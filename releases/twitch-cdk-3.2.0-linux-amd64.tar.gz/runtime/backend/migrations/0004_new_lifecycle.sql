-- 0004_new_lifecycle.sql
-- 重构账号与 CDK 的生命周期。
--
-- 账号:
--   status: 'unused' (未使用) | 'claiming' (掉宝中) | 'success' | 'failed'
--   used_at: 标记何时被取走(进入 claiming/success/failed 之一)
--   claim_deadline: claiming 状态自动转 failed 的截止时间
--   全部 used_at 不为空的账号,在 account_retention_hours 后自动删除
--
-- CDK:
--   exported (bool): 是否已被 /api/cdks/export 导出过
--   exported_at: 导出时间,用于 cdk_retention_hours 后自动删除
--   status 统一为 'claimed' (worker 上报过即此值);不再使用 unused/expired

BEGIN;

-- ===== accounts =====
ALTER TABLE accounts
    ADD COLUMN IF NOT EXISTS used_at        TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS claim_deadline TIMESTAMPTZ;

-- 旧 status 映射到新 status
UPDATE accounts SET status = 'unused'   WHERE status IN ('idle', 'failed');
UPDATE accounts SET status = 'claiming' WHERE status = 'working';
-- success 不变

-- 补 used_at: 当前已使用的账号(claiming/success)给一个 NOW,让 retention 立即开始倒计时
UPDATE accounts SET used_at = NOW()
WHERE status IN ('claiming', 'success') AND used_at IS NULL;

-- claim_deadline: 把旧的 working(现 claiming)行设一个已过期的 deadline
UPDATE accounts SET claim_deadline = NOW()
WHERE status = 'claiming' AND claim_deadline IS NULL;

CREATE INDEX IF NOT EXISTS idx_accounts_status     ON accounts (status);
CREATE INDEX IF NOT EXISTS idx_accounts_used_at    ON accounts (used_at);
DROP INDEX IF EXISTS idx_accounts_worker_id;

-- ===== cdks =====
ALTER TABLE cdks
    ADD COLUMN IF NOT EXISTS exported    BOOLEAN     NOT NULL DEFAULT false,
    ADD COLUMN IF NOT EXISTS exported_at TIMESTAMPTZ;

-- 旧的 expired 视为已导出 (会被 48h 后清理)
UPDATE cdks SET exported = true, exported_at = COALESCE(exported_at, NOW())
WHERE status = 'expired';

-- 把所有 status 统一成 'claimed' (worker 上报过的标识)
UPDATE cdks SET status = 'claimed'
WHERE status IN ('unused', 'claimed', 'expired');

CREATE INDEX IF NOT EXISTS idx_cdks_exported     ON cdks (exported);
CREATE INDEX IF NOT EXISTS idx_cdks_exported_at  ON cdks (exported_at);

COMMIT;
