-- 0002_workers_unique.sql - allow ON CONFLICT for worker upsert

-- Ensure worker_name uniqueness (clean duplicates first if any).
DELETE FROM workers w USING workers w2
WHERE w.worker_name = w2.worker_name AND w.id > w2.id;

ALTER TABLE workers ADD CONSTRAINT workers_worker_name_key UNIQUE (worker_name);
