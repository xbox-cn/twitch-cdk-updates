-- 0018_liveness.sql
-- Account liveness checks are driven by Worker clients. The server keeps a
-- cursor on the run and marks one account at a time, so a pool with hundreds
-- of thousands of accounts never needs a materialized queue table.

ALTER TABLE accounts
    ADD COLUMN IF NOT EXISTS liveness_state    VARCHAR(16) NOT NULL DEFAULT 'idle',
    ADD COLUMN IF NOT EXISTS liveness_token    UUID,
    ADD COLUMN IF NOT EXISTS liveness_deadline TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS liveness_checked_at TIMESTAMPTZ,
    ADD COLUMN IF NOT EXISTS liveness_run_id   BIGINT;

CREATE INDEX IF NOT EXISTS idx_accounts_liveness_scan
    ON accounts (status, liveness_state, id);
CREATE INDEX IF NOT EXISTS idx_accounts_liveness_deadline
    ON accounts (liveness_deadline)
    WHERE liveness_state = 'checking';

CREATE TABLE IF NOT EXISTS liveness_runs (
    id               BIGSERIAL PRIMARY KEY,
    status           VARCHAR(16) NOT NULL DEFAULT 'running',
    trigger_kind     VARCHAR(16) NOT NULL DEFAULT 'auto',
    cursor_id        BIGINT NOT NULL DEFAULT 0,
    total            BIGINT NOT NULL DEFAULT 0,
    checked          BIGINT NOT NULL DEFAULT 0,
    valid            BIGINT NOT NULL DEFAULT 0,
    invalid          BIGINT NOT NULL DEFAULT 0,
    errors           BIGINT NOT NULL DEFAULT 0,
    started_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    finished_at      TIMESTAMPTZ,
    last_activity_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_liveness_runs_status_started
    ON liveness_runs (status, started_at DESC);

INSERT INTO settings (key, value) VALUES
    ('liveness_enabled', 'true'),
    ('liveness_interval_hours', '24'),
    ('liveness_only_when_idle', 'true')
ON CONFLICT (key) DO NOTHING;
