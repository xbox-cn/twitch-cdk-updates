-- Normalize the account status default and replace the obsolete claim index.
-- Existing rows were migrated to 'available' in 0013; the column default was
-- left at 'unused', which made status-less inserts unclaimable.
ALTER TABLE accounts ALTER COLUMN status SET DEFAULT 'available';

DROP INDEX IF EXISTS idx_accounts_claimable;
CREATE INDEX IF NOT EXISTS idx_accounts_available_created
    ON accounts (created_at, id)
    WHERE status = 'available';
